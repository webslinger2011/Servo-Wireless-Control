
This program shows how to wirelessly control two servos using
the arduino pro mini and the nrf24L01 module.

We'll be using a joystick to control each servo and as a bonus, I've also included
a blink and a latching program using an interrupt to switch an led ON and OFF.

Two buttons will be used to switch the other led ON or OFF.



